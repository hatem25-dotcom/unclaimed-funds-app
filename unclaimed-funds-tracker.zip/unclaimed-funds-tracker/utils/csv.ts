import Papa from "papaparse";
import { Record, Status, US_STATES, US_STATE_NAMES } from "@/types";

function makeId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

function normalizeKey(k: string): string {
  return k.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function pickField(row: any, candidates: string[]): string {
  const keys = Object.keys(row);
  for (const cand of candidates) {
    const target = normalizeKey(cand);
    for (const k of keys) {
      if (normalizeKey(k) === target) {
        const v = row[k];
        return v == null ? "" : String(v).trim();
      }
    }
  }
  return "";
}

function parseAmount(raw: string): number {
  if (!raw) return 0;
  const cleaned = raw.replace(/[^0-9.\-]/g, "");
  const n = parseFloat(cleaned);
  return Number.isFinite(n) ? n : 0;
}

function normalizeState(raw: string): string {
  if (!raw) return "";
  const t = raw.trim();
  const upper = t.toUpperCase();
  if (US_STATES.includes(upper)) return upper;
  const lower = t.toLowerCase();
  for (const code of US_STATES) {
    if (US_STATE_NAMES[code].toLowerCase() === lower) return code;
  }
  return upper.slice(0, 2);
}

function normalizeStatus(raw: string): Status {
  const t = (raw || "").toLowerCase().trim();
  if (t.includes("contact")) return "Contacted";
  if (t.includes("repli")) return "Replied";
  return "Pending";
}

function parseBool(raw: any): boolean {
  if (typeof raw === "boolean") return raw;
  const t = String(raw || "").toLowerCase().trim();
  return t === "true" || t === "1" || t === "yes" || t === "y" || t === "★" || t === "*";
}

function rowToRecord(row: any): Record | null {
  const fullName = pickField(row, ["full name", "name", "fullname", "person"]);
  const email = pickField(row, ["email", "e-mail", "mail"]);
  if (!fullName && !email) return null;
  const amount = parseAmount(pickField(row, ["amount", "value", "funds", "balance", "money"]));
  const state = normalizeState(pickField(row, ["state", "st", "region"]));
  const status = normalizeStatus(pickField(row, ["status"]));
  const starred = parseBool(pickField(row, ["star", "starred", "favorite", "fav"]));
  return {
    id: makeId(),
    fullName: fullName || "(no name)",
    amount,
    state,
    email: email.toLowerCase(),
    status,
    starred,
    createdAt: Date.now(),
  };
}

export function parseCsvText(text: string): Record[] {
  const result = Papa.parse<any>(text, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  });
  const rows = (result.data || []).filter((r) => r && typeof r === "object");
  const out: Record[] = [];
  for (const row of rows) {
    const rec = rowToRecord(row);
    if (rec) out.push(rec);
  }
  return out;
}

export function parseJsonText(text: string): Record[] {
  let data: any;
  try {
    data = JSON.parse(text);
  } catch {
    return [];
  }
  const arr = Array.isArray(data) ? data : Array.isArray(data?.records) ? data.records : [];
  const out: Record[] = [];
  for (const row of arr) {
    if (!row || typeof row !== "object") continue;
    const rec = rowToRecord(row);
    if (rec) out.push(rec);
  }
  return out;
}

export function recordsToCsv(records: Record[]): string {
  return Papa.unparse(
    records.map((r) => ({
      "Full Name": r.fullName,
      Amount: r.amount,
      State: r.state,
      Email: r.email,
      Status: r.status,
      Starred: r.starred ? "true" : "false",
    }))
  );
}

export function recordsToJson(records: Record[]): string {
  return JSON.stringify(
    records.map((r) => ({
      fullName: r.fullName,
      amount: r.amount,
      state: r.state,
      email: r.email,
      status: r.status,
      starred: r.starred,
    })),
    null,
    2
  );
}

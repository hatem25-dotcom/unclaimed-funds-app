import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";

import { Record } from "@/types";
import {
  parseCsvText,
  parseJsonText,
  recordsToCsv,
  recordsToJson,
} from "@/utils/csv";

export type ExportFormat = "csv" | "json";

function timestamp(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}

export async function exportRecords(records: Record[], format: ExportFormat): Promise<string> {
  const filename = `unclaimed-funds_${timestamp()}.${format}`;
  const content = format === "csv" ? recordsToCsv(records) : recordsToJson(records);

  if (Platform.OS === "web") {
    const blob = new Blob([content], {
      type: format === "csv" ? "text/csv" : "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return filename;
  }

  const dir = (FileSystem as any).documentDirectory || (FileSystem as any).cacheDirectory;
  const fileUri = `${dir}${filename}`;
  await FileSystem.writeAsStringAsync(fileUri, content, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(fileUri, {
      mimeType: format === "csv" ? "text/csv" : "application/json",
      dialogTitle: "Save or share your data backup",
      UTI: format === "csv" ? "public.comma-separated-values-text" : "public.json",
    });
  }
  return filename;
}

export async function pickAndParseFile(): Promise<Record[]> {
  const res = await DocumentPicker.getDocumentAsync({
    type: ["text/csv", "application/json", "text/plain", "*/*"],
    copyToCacheDirectory: true,
  });
  if (res.canceled) return [];
  const file = res.assets[0];
  let text: string;
  if (Platform.OS === "web") {
    const blob = await fetch(file.uri).then((r) => r.blob());
    text = await blob.text();
  } else {
    text = await fetch(file.uri).then((r) => r.text());
  }
  const name = (file.name || "").toLowerCase();
  if (name.endsWith(".json")) {
    return parseJsonText(text);
  }
  // try JSON first if it starts with { or [, else CSV
  const trimmed = text.trim();
  if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
    const parsed = parseJsonText(text);
    if (parsed.length > 0) return parsed;
  }
  return parseCsvText(text);
}

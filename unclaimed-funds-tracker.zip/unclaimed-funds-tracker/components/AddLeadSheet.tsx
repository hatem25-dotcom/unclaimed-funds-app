import { Feather } from "@expo/vector-icons";
import React, { useEffect, useState } from "react";
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  STATUSES,
  Status,
  US_STATES,
  US_STATE_NAMES,
} from "@/types";

const EMPTY = {
  fullName: "",
  amount: "",
  state: "",
  email: "",
  status: "Pending" as Status,
};

export function AddLeadSheet({
  visible,
  onClose,
  onSave,
}: {
  visible: boolean;
  onClose: () => void;
  onSave: (lead: {
    fullName: string;
    amount: number;
    state: string;
    email: string;
    status: Status;
    starred: boolean;
  }) => void;
}) {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const [form, setForm] = useState(EMPTY);
  const [showStates, setShowStates] = useState(false);

  useEffect(() => {
    if (visible) setForm(EMPTY);
  }, [visible]);

  const handleSave = () => {
    const fullName = form.fullName.trim();
    if (!fullName) {
      Alert.alert("Name required", "Please enter the full name.");
      return;
    }
    const amount = parseFloat(form.amount.replace(/[^0-9.]/g, "")) || 0;
    onSave({
      fullName,
      amount,
      state: form.state,
      email: form.email.trim().toLowerCase(),
      status: form.status,
      starred: false,
    });
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={[styles.container, { backgroundColor: c.background, paddingTop: insets.top + 8 }]}
      >
        <View style={styles.header}>
          <Pressable onPress={onClose}>
            <Text style={[styles.headerBtn, { color: c.mutedForeground }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.title, { color: c.foreground }]}>Add Lead</Text>
          <Pressable onPress={handleSave}>
            <Text style={[styles.headerBtn, { color: c.primary }]}>Save</Text>
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={{ padding: 16, paddingBottom: 60 }}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={[styles.label, { color: c.mutedForeground }]}>FULL NAME *</Text>
          <TextInput
            value={form.fullName}
            onChangeText={(t) => setForm({ ...form, fullName: t })}
            placeholder="Jane Doe"
            placeholderTextColor={c.mutedForeground}
            autoCapitalize="words"
            style={[styles.input, { backgroundColor: c.card, borderColor: c.border, color: c.foreground }]}
          />

          <Text style={[styles.label, { color: c.mutedForeground }]}>AMOUNT</Text>
          <TextInput
            value={form.amount}
            onChangeText={(t) => setForm({ ...form, amount: t.replace(/[^0-9.]/g, "") })}
            placeholder="0"
            placeholderTextColor={c.mutedForeground}
            keyboardType="decimal-pad"
            style={[styles.input, { backgroundColor: c.card, borderColor: c.border, color: c.foreground }]}
          />

          <Text style={[styles.label, { color: c.mutedForeground }]}>STATE</Text>
          <Pressable
            onPress={() => setShowStates(true)}
            style={[styles.picker, { backgroundColor: c.card, borderColor: c.border }]}
          >
            <Text style={{ color: form.state ? c.foreground : c.mutedForeground, fontFamily: "Inter_500Medium", fontSize: 15 }}>
              {form.state ? `${form.state} — ${US_STATE_NAMES[form.state]}` : "Select state"}
            </Text>
            <Feather name="chevron-down" size={18} color={c.mutedForeground} />
          </Pressable>

          <Text style={[styles.label, { color: c.mutedForeground }]}>EMAIL</Text>
          <TextInput
            value={form.email}
            onChangeText={(t) => setForm({ ...form, email: t })}
            placeholder="jane@example.com"
            placeholderTextColor={c.mutedForeground}
            autoCapitalize="none"
            keyboardType="email-address"
            autoCorrect={false}
            style={[styles.input, { backgroundColor: c.card, borderColor: c.border, color: c.foreground }]}
          />

          <Text style={[styles.label, { color: c.mutedForeground }]}>STATUS</Text>
          <View style={styles.chipRow}>
            {STATUSES.map((s) => {
              const sel = form.status === s;
              return (
                <Pressable
                  key={s}
                  onPress={() => setForm({ ...form, status: s })}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: sel ? c.primary : c.card,
                      borderColor: sel ? c.primary : c.border,
                    },
                  ]}
                >
                  <Text
                    style={{
                      color: sel ? c.primaryForeground : c.foreground,
                      fontFamily: "Inter_600SemiBold",
                      fontSize: 13,
                    }}
                  >
                    {s}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </ScrollView>

        <Modal
          visible={showStates}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={() => setShowStates(false)}
        >
          <View style={[styles.container, { backgroundColor: c.background, paddingTop: insets.top + 8 }]}>
            <View style={styles.header}>
              <Pressable onPress={() => setShowStates(false)}>
                <Text style={[styles.headerBtn, { color: c.mutedForeground }]}>Close</Text>
              </Pressable>
              <Text style={[styles.title, { color: c.foreground }]}>Select State</Text>
              <View style={{ width: 50 }} />
            </View>
            <FlatList
              data={US_STATES}
              keyExtractor={(s) => s}
              renderItem={({ item }) => {
                const sel = form.state === item;
                return (
                  <Pressable
                    onPress={() => {
                      setForm({ ...form, state: item });
                      setShowStates(false);
                    }}
                    style={[styles.stateRow, { borderBottomColor: c.border }]}
                  >
                    <Text style={{ color: c.foreground, fontFamily: "Inter_500Medium", fontSize: 15 }}>
                      {item} — {US_STATE_NAMES[item]}
                    </Text>
                    {sel ? <Feather name="check" size={18} color={c.primary} /> : null}
                  </Pressable>
                );
              }}
            />
          </View>
        </Modal>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerBtn: { fontSize: 15, fontFamily: "Inter_500Medium" },
  title: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
  label: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    marginTop: 18,
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  input: {
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  picker: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
  },
  chipRow: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
  },
  stateRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

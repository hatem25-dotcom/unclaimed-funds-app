import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import * as WebBrowser from "expo-web-browser";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { formatMoney, useRecords } from "@/contexts/RecordsContext";
import { useColors } from "@/hooks/useColors";
import { Record, STATUSES, Status, US_STATE_NAMES } from "@/types";

function applyTemplate(tpl: string, r: Record): string {
  return tpl
    .replace(/\{name\}/g, r.fullName || "")
    .replace(/\{state\}/g, US_STATE_NAMES[r.state] || r.state || "")
    .replace(/\{amount\}/g, formatMoney(r.amount));
}

export function RecordDetailSheet({
  record,
  onClose,
}: {
  record: Record | null;
  onClose: () => void;
}) {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const { template, setTemplate, toggleStar, setStatus, deleteRecord } = useRecords();
  const [editingTpl, setEditingTpl] = useState(false);
  const [draftTpl, setDraftTpl] = useState(template);
  const [customQuery, setCustomQuery] = useState("");

  React.useEffect(() => {
    setDraftTpl(template);
  }, [template, record]);

  const message = useMemo(() => (record ? applyTemplate(template, record) : ""), [template, record]);

  if (!record) return null;

  const copyMessage = async () => {
    await Clipboard.setStringAsync(message);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("Copied", "Message copied to clipboard");
  };

  const openSearch = (url: string) => {
    WebBrowser.openBrowserAsync(url).catch(() => {});
  };

  const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(record.fullName + " " + (US_STATE_NAMES[record.state] || ""))}`;
  const linkedinUrl = `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(record.fullName)}`;
  const customUrl = customQuery
    ? `https://www.google.com/search?q=${encodeURIComponent(customQuery + " " + record.fullName)}`
    : "";

  return (
    <Modal
      visible={!!record}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={[styles.container, { backgroundColor: c.background, paddingTop: insets.top + 8 }]}>
        <View style={styles.header}>
          <Pressable onPress={onClose}>
            <Text style={[styles.headerBtn, { color: c.mutedForeground }]}>Close</Text>
          </Pressable>
          <Pressable onPress={() => toggleStar(record.id)} hitSlop={10}>
            <Feather name="star" size={22} color={record.starred ? c.star : c.mutedForeground} />
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 40 }}>
          <Text style={[styles.name, { color: c.foreground }]}>{record.fullName}</Text>
          <Text style={[styles.amount, { color: c.primary }]}>{formatMoney(record.amount)}</Text>
          {record.amount > 10000 ? (
            <View style={[styles.alert, { backgroundColor: c.primary + "15", borderColor: c.primary }]}>
              <Feather name="zap" size={14} color={c.primary} />
              <Text style={[styles.alertText, { color: c.primary }]}>High-value lead</Text>
            </View>
          ) : null}

          <View style={[styles.infoCard, { backgroundColor: c.card, borderColor: c.border }]}>
            <InfoRow label="Email" value={record.email || "—"} c={c} />
            <InfoRow label="State" value={record.state ? `${record.state} — ${US_STATE_NAMES[record.state] || ""}` : "—"} c={c} />
          </View>

          <Text style={[styles.section, { color: c.mutedForeground }]}>STATUS</Text>
          <View style={styles.chips}>
            {STATUSES.map((s) => {
              const active = record.status === s;
              return (
                <Pressable
                  key={s}
                  onPress={() => setStatus(record.id, s as Status)}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: active ? c.primary : c.card,
                      borderColor: active ? c.primary : c.border,
                    },
                  ]}
                >
                  <Text
                    style={{
                      color: active ? c.primaryForeground : c.foreground,
                      fontFamily: "Inter_500Medium",
                      fontSize: 13,
                    }}
                  >
                    {s}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <Text style={[styles.section, { color: c.mutedForeground }]}>SEARCH</Text>
          <View style={{ gap: 8 }}>
            <SearchButton icon="globe" label="Google" onPress={() => openSearch(googleUrl)} c={c} />
            <SearchButton icon="linkedin" label="LinkedIn" onPress={() => openSearch(linkedinUrl)} c={c} />
            <View style={[styles.customSearch, { backgroundColor: c.card, borderColor: c.border }]}>
              <TextInput
                value={customQuery}
                onChangeText={setCustomQuery}
                placeholder="Custom search..."
                placeholderTextColor={c.mutedForeground}
                style={{ flex: 1, color: c.foreground, fontFamily: "Inter_500Medium", fontSize: 14 }}
              />
              <Pressable
                disabled={!customQuery}
                onPress={() => openSearch(customUrl)}
                style={[styles.iconBtn, { backgroundColor: customQuery ? c.primary : c.muted }]}
              >
                <Feather name="search" size={16} color={customQuery ? c.primaryForeground : c.mutedForeground} />
              </Pressable>
            </View>
          </View>

          <View style={[styles.sectionHeader, { marginTop: 24 }]}>
            <Text style={[styles.section, { color: c.mutedForeground, marginTop: 0 }]}>MESSAGE</Text>
            <Pressable onPress={() => setEditingTpl((v) => !v)}>
              <Text style={[styles.editLink, { color: c.primary }]}>
                {editingTpl ? "Done" : "Edit template"}
              </Text>
            </Pressable>
          </View>

          {editingTpl ? (
            <>
              <TextInput
                value={draftTpl}
                onChangeText={setDraftTpl}
                multiline
                style={[styles.tplInput, { backgroundColor: c.card, borderColor: c.border, color: c.foreground }]}
              />
              <Text style={[styles.hint, { color: c.mutedForeground }]}>
                Use {"{name}"}, {"{state}"}, {"{amount}"}
              </Text>
              <Pressable
                onPress={() => {
                  setTemplate(draftTpl);
                  setEditingTpl(false);
                }}
                style={[styles.saveBtn, { backgroundColor: c.secondary }]}
              >
                <Text style={{ color: c.foreground, fontFamily: "Inter_500Medium" }}>Save template</Text>
              </Pressable>
            </>
          ) : null}

          <View style={[styles.messageBox, { backgroundColor: c.card, borderColor: c.border }]}>
            <Text style={[styles.messageText, { color: c.foreground }]}>{message}</Text>
          </View>

          <View style={styles.actionRow}>
            <Pressable onPress={copyMessage} style={[styles.copyBtn, { backgroundColor: c.secondary, flex: 1 }]}>
              <Feather name="copy" size={16} color={c.foreground} />
              <Text style={[styles.copyText, { color: c.foreground }]}>Copy</Text>
            </Pressable>
            <Pressable
              onPress={async () => {
                if (!record.email) {
                  Alert.alert("No email", "This lead has no email address.");
                  return;
                }
                const subject = "Unclaimed Funds Notification";
                const url = `mailto:${encodeURIComponent(record.email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
                try {
                  await Linking.openURL(url);
                } catch {
                  Alert.alert("Cannot open email", "No email app is configured on this device.");
                }
              }}
              style={[styles.copyBtn, { backgroundColor: c.primary, flex: 1 }]}
            >
              <Feather name="mail" size={16} color={c.primaryForeground} />
              <Text style={[styles.copyText, { color: c.primaryForeground }]}>Email</Text>
            </Pressable>
          </View>

          <Pressable
            onPress={() => {
              Alert.alert("Delete Record", `Delete ${record.fullName}?`, [
                { text: "Cancel", style: "cancel" },
                {
                  text: "Delete",
                  style: "destructive",
                  onPress: () => {
                    deleteRecord(record.id);
                    onClose();
                  },
                },
              ]);
            }}
            style={styles.deleteBtn}
          >
            <Feather name="trash-2" size={14} color={c.destructive} />
            <Text style={[styles.deleteText, { color: c.destructive }]}>Delete record</Text>
          </Pressable>
        </ScrollView>
      </View>
    </Modal>
  );
}

function InfoRow({ label, value, c }: { label: string; value: string; c: any }) {
  return (
    <View style={styles.infoRow}>
      <Text style={{ color: c.mutedForeground, fontSize: 13, fontFamily: "Inter_500Medium" }}>{label}</Text>
      <Text style={{ color: c.foreground, fontSize: 14, fontFamily: "Inter_500Medium", flex: 1, textAlign: "right" }} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

function SearchButton({ icon, label, onPress, c }: { icon: any; label: string; onPress: () => void; c: any }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.searchBtn,
        { backgroundColor: c.card, borderColor: c.border, opacity: pressed ? 0.7 : 1 },
      ]}
    >
      <Feather name={icon} size={16} color={c.foreground} />
      <Text style={{ color: c.foreground, fontFamily: "Inter_500Medium", flex: 1 }}>{label}</Text>
      <Feather name="external-link" size={14} color={c.mutedForeground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  headerBtn: { fontSize: 15, fontFamily: "Inter_500Medium" },
  name: { fontSize: 26, fontFamily: "Inter_700Bold", marginTop: 8 },
  amount: { fontSize: 32, fontFamily: "Inter_700Bold", marginTop: 4 },
  alert: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    marginTop: 10,
  },
  alertText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  infoCard: {
    marginTop: 20,
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 10,
  },
  infoRow: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
  section: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    marginTop: 24,
    marginBottom: 10,
    letterSpacing: 0.5,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginBottom: 10,
  },
  editLink: { fontSize: 13, fontFamily: "Inter_500Medium" },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
  },
  searchBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
  },
  customSearch: {
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: 14,
    paddingRight: 6,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 8,
  },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  tplInput: {
    minHeight: 100,
    padding: 12,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    textAlignVertical: "top",
  },
  hint: { fontSize: 12, marginTop: 6, fontFamily: "Inter_400Regular" },
  saveBtn: {
    marginTop: 8,
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  messageBox: {
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    marginTop: 4,
  },
  messageText: { fontSize: 14, lineHeight: 20, fontFamily: "Inter_400Regular" },
  actionRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 12,
  },
  copyBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
    borderRadius: 12,
  },
  copyText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  deleteBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 16,
    marginTop: 16,
  },
  deleteText: { fontSize: 13, fontFamily: "Inter_500Medium" },
});

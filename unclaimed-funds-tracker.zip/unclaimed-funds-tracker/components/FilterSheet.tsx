import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  DEFAULT_FILTERS,
  Filters,
  US_STATES,
  US_STATE_NAMES,
} from "@/types";

export function FilterSheet({
  visible,
  filters,
  onClose,
  onApply,
}: {
  visible: boolean;
  filters: Filters;
  onClose: () => void;
  onApply: (f: Filters) => void;
}) {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const [draft, setDraft] = useState<Filters>(filters);
  const [showStates, setShowStates] = useState(false);

  React.useEffect(() => {
    if (visible) setDraft(filters);
  }, [visible, filters]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={[styles.container, { backgroundColor: c.background, paddingTop: insets.top + 8 }]}>
        <View style={styles.header}>
          <Pressable onPress={onClose}>
            <Text style={[styles.headerBtn, { color: c.mutedForeground }]}>Cancel</Text>
          </Pressable>
          <Text style={[styles.title, { color: c.foreground }]}>Filters</Text>
          <Pressable onPress={() => setDraft(DEFAULT_FILTERS)}>
            <Text style={[styles.headerBtn, { color: c.primary }]}>Reset</Text>
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 120 }}>
          <Text style={[styles.label, { color: c.mutedForeground }]}>STARRED</Text>
          <Pressable
            onPress={() => setDraft({ ...draft, starredOnly: !draft.starredOnly })}
            style={[
              styles.toggle,
              { backgroundColor: c.card, borderColor: c.border },
            ]}
          >
            <Feather
              name="star"
              size={18}
              color={draft.starredOnly ? c.star : c.mutedForeground}
            />
            <Text style={[styles.toggleText, { color: c.foreground }]}>
              Show starred only
            </Text>
            <View
              style={[
                styles.checkbox,
                {
                  backgroundColor: draft.starredOnly ? c.primary : "transparent",
                  borderColor: draft.starredOnly ? c.primary : c.border,
                },
              ]}
            >
              {draft.starredOnly ? (
                <Feather name="check" size={14} color={c.primaryForeground} />
              ) : null}
            </View>
          </Pressable>

          <Text style={[styles.label, { color: c.mutedForeground }]}>STATE</Text>
          <Pressable
            onPress={() => setShowStates(true)}
            style={[styles.input, { backgroundColor: c.card, borderColor: c.border }]}
          >
            <Text style={{ color: draft.state ? c.foreground : c.mutedForeground, fontFamily: "Inter_500Medium" }}>
              {draft.state ? `${draft.state} — ${US_STATE_NAMES[draft.state]}` : "All states"}
            </Text>
            <Feather name="chevron-down" size={18} color={c.mutedForeground} />
          </Pressable>

          <Text style={[styles.label, { color: c.mutedForeground }]}>MINIMUM AMOUNT</Text>
          <TextInput
            value={draft.minAmount}
            onChangeText={(t) => setDraft({ ...draft, minAmount: t.replace(/[^0-9.]/g, "") })}
            placeholder="e.g. 1000"
            placeholderTextColor={c.mutedForeground}
            keyboardType="decimal-pad"
            style={[styles.amountInput, { backgroundColor: c.card, borderColor: c.border, color: c.foreground }]}
          />
        </ScrollView>

        <View style={[styles.footer, { paddingBottom: insets.bottom + 12, backgroundColor: c.background, borderTopColor: c.border }]}>
          <Pressable
            onPress={() => {
              onApply(draft);
              onClose();
            }}
            style={[styles.applyBtn, { backgroundColor: c.primary }]}
          >
            <Text style={[styles.applyText, { color: c.primaryForeground }]}>Apply Filters</Text>
          </Pressable>
        </View>

        <Modal visible={showStates} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowStates(false)}>
          <View style={[styles.container, { backgroundColor: c.background, paddingTop: insets.top + 8 }]}>
            <View style={styles.header}>
              <Pressable onPress={() => setShowStates(false)}>
                <Text style={[styles.headerBtn, { color: c.mutedForeground }]}>Close</Text>
              </Pressable>
              <Text style={[styles.title, { color: c.foreground }]}>Select State</Text>
              <View style={{ width: 50 }} />
            </View>
            <FlatList
              data={[null, ...US_STATES] as (string | null)[]}
              keyExtractor={(item) => item ?? "ALL"}
              renderItem={({ item }) => {
                const selected = draft.state === item;
                return (
                  <Pressable
                    onPress={() => {
                      setDraft({ ...draft, state: item });
                      setShowStates(false);
                    }}
                    style={[styles.stateRow, { borderBottomColor: c.border }]}
                  >
                    <Text style={{ color: c.foreground, fontFamily: "Inter_500Medium", fontSize: 15 }}>
                      {item ? `${item} — ${US_STATE_NAMES[item]}` : "All states"}
                    </Text>
                    {selected ? <Feather name="check" size={18} color={c.primary} /> : null}
                  </Pressable>
                );
              }}
            />
          </View>
        </Modal>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerBtn: { fontSize: 15, fontFamily: "Inter_500Medium" },
  title: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
  label: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    marginTop: 18,
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  toggle: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  toggleText: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 15 },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
  },
  amountInput: {
    padding: 14,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  footer: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  applyBtn: {
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
  },
  applyText: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  stateRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

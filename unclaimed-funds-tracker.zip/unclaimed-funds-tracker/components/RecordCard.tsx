import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import { Platform, Pressable, StyleSheet, Text, View } from "react-native";

import { useColors } from "@/hooks/useColors";
import { Record } from "@/types";
import { formatMoney } from "@/contexts/RecordsContext";

const STATUS_COLORS: { [k: string]: string } = {
  Pending: "#a1a1aa",
  Contacted: "#3b82f6",
  Replied: "#22c55e",
  "No Response": "#ef4444",
};

export function RecordCard({
  record,
  onPress,
  onToggleStar,
}: {
  record: Record;
  onPress: () => void;
  onToggleStar: () => void;
}) {
  const c = useColors();
  const isHigh = record.amount > 10000;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: c.card,
          borderColor: isHigh ? c.primary : c.border,
          borderWidth: isHigh ? 1 : StyleSheet.hairlineWidth,
          opacity: pressed ? 0.7 : 1,
        },
      ]}
    >
      <View style={styles.row}>
        <View style={{ flex: 1, paddingRight: 8 }}>
          <Text style={[styles.name, { color: c.foreground }]} numberOfLines={1}>
            {record.fullName}
          </Text>
          {record.email ? (
            <Text style={[styles.email, { color: c.mutedForeground }]} numberOfLines={1}>
              {record.email}
            </Text>
          ) : null}
        </View>
        <Pressable
          onPress={() => {
            if (Platform.OS !== "web") Haptics.selectionAsync();
            onToggleStar();
          }}
          hitSlop={12}
          style={styles.starBtn}
        >
          <Feather
            name="star"
            size={22}
            color={record.starred ? c.star : c.mutedForeground}
            style={record.starred ? { opacity: 1 } : { opacity: 0.5 }}
          />
        </Pressable>
      </View>

      <View style={styles.bottomRow}>
        <Text style={[styles.amount, { color: isHigh ? c.primary : c.foreground }]}>
          {formatMoney(record.amount)}
        </Text>
        <View style={styles.tags}>
          {record.state ? (
            <View style={[styles.pill, { backgroundColor: c.secondary }]}>
              <Text style={[styles.pillText, { color: c.secondaryForeground }]}>
                {record.state}
              </Text>
            </View>
          ) : null}
          <View
            style={[
              styles.pill,
              { backgroundColor: STATUS_COLORS[record.status] + "22" },
            ]}
          >
            <View
              style={[
                styles.dot,
                { backgroundColor: STATUS_COLORS[record.status] },
              ]}
            />
            <Text style={[styles.pillText, { color: STATUS_COLORS[record.status] }]}>
              {record.status}
            </Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
  },
  row: { flexDirection: "row", alignItems: "flex-start" },
  name: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  email: { fontSize: 12, marginTop: 2, fontFamily: "Inter_400Regular" },
  starBtn: { padding: 2 },
  bottomRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 12,
  },
  amount: { fontSize: 18, fontFamily: "Inter_700Bold" },
  tags: { flexDirection: "row", gap: 6 },
  pill: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    gap: 6,
  },
  pillText: { fontSize: 11, fontFamily: "Inter_500Medium" },
  dot: { width: 6, height: 6, borderRadius: 3 },
});

import { Feather } from "@expo/vector-icons";
import React, { useMemo } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { formatMoney, useRecords } from "@/contexts/RecordsContext";
import { useColors } from "@/hooks/useColors";
import { US_STATE_NAMES } from "@/types";

export default function DashboardScreen() {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const { records } = useRecords();

  const stats = useMemo(() => {
    const total = records.length;
    const sum = records.reduce((s, r) => s + r.amount, 0);
    const starred = records.filter((r) => r.starred).length;
    const highValue = records.filter((r) => r.amount > 10000).length;

    const byState: { [k: string]: { count: number; sum: number } } = {};
    for (const r of records) {
      const k = r.state || "—";
      if (!byState[k]) byState[k] = { count: 0, sum: 0 };
      byState[k].count++;
      byState[k].sum += r.amount;
    }
    const stateList = Object.entries(byState)
      .sort((a, b) => b[1].sum - a[1].sum);

    const topRecords = [...records].sort((a, b) => b.amount - a.amount).slice(0, 5);

    const byStatus: { [k: string]: number } = {};
    for (const r of records) {
      byStatus[r.status] = (byStatus[r.status] || 0) + 1;
    }

    return { total, sum, starred, highValue, stateList, topRecords, byStatus };
  }, [records]);

  return (
    <ScrollView
      style={{ backgroundColor: c.background }}
      contentContainerStyle={{ paddingTop: insets.top + 8, paddingBottom: insets.bottom + 100, paddingHorizontal: 16 }}
    >
      <Text style={[styles.title, { color: c.foreground }]}>Dashboard</Text>
      <Text style={[styles.subtitle, { color: c.mutedForeground }]}>Overview of all leads</Text>

      <View style={styles.statGrid}>
        <StatCard label="Total leads" value={String(stats.total)} c={c} icon="users" />
        <StatCard label="Total amount" value={formatMoney(stats.sum)} c={c} icon="dollar-sign" highlight />
        <StatCard label="Starred" value={String(stats.starred)} c={c} icon="star" />
        <StatCard label="Above $10k" value={String(stats.highValue)} c={c} icon="zap" />
      </View>

      {records.length === 0 ? (
        <View style={[styles.emptyCard, { backgroundColor: c.card, borderColor: c.border }]}>
          <Feather name="bar-chart-2" size={32} color={c.mutedForeground} />
          <Text style={[styles.emptyText, { color: c.mutedForeground }]}>
            Import some records to see your dashboard.
          </Text>
        </View>
      ) : (
        <>
          <Section title="Top amounts" c={c}>
            <View style={[styles.listCard, { backgroundColor: c.card, borderColor: c.border }]}>
              {stats.topRecords.map((r, i) => (
                <View
                  key={r.id}
                  style={[
                    styles.row,
                    i < stats.topRecords.length - 1 && {
                      borderBottomColor: c.border,
                      borderBottomWidth: StyleSheet.hairlineWidth,
                    },
                  ]}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.rowName, { color: c.foreground }]} numberOfLines={1}>
                      {r.fullName}
                    </Text>
                    <Text style={[styles.rowSub, { color: c.mutedForeground }]}>
                      {r.state || "—"} · {r.status}
                    </Text>
                  </View>
                  <Text style={[styles.rowAmount, { color: c.primary }]}>
                    {formatMoney(r.amount)}
                  </Text>
                </View>
              ))}
            </View>
          </Section>

          <Section title="By state" c={c}>
            <View style={[styles.listCard, { backgroundColor: c.card, borderColor: c.border }]}>
              {stats.stateList.map(([code, info], i) => {
                const pct = stats.sum > 0 ? (info.sum / stats.sum) * 100 : 0;
                return (
                  <View
                    key={code}
                    style={[
                      styles.row,
                      i < stats.stateList.length - 1 && {
                        borderBottomColor: c.border,
                        borderBottomWidth: StyleSheet.hairlineWidth,
                      },
                    ]}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.rowName, { color: c.foreground }]}>
                        {code === "—" ? "Unknown" : `${code} — ${US_STATE_NAMES[code] || ""}`}
                      </Text>
                      <View style={[styles.barTrack, { backgroundColor: c.muted }]}>
                        <View style={[styles.barFill, { backgroundColor: c.primary, width: `${pct}%` }]} />
                      </View>
                    </View>
                    <View style={{ alignItems: "flex-end", marginLeft: 12 }}>
                      <Text style={[styles.rowAmount, { color: c.foreground }]}>{formatMoney(info.sum)}</Text>
                      <Text style={[styles.rowSub, { color: c.mutedForeground }]}>{info.count} lead{info.count === 1 ? "" : "s"}</Text>
                    </View>
                  </View>
                );
              })}
            </View>
          </Section>

          <Section title="By status" c={c}>
            <View style={[styles.listCard, { backgroundColor: c.card, borderColor: c.border }]}>
              {Object.entries(stats.byStatus).map(([s, n], i, arr) => (
                <View
                  key={s}
                  style={[
                    styles.row,
                    i < arr.length - 1 && {
                      borderBottomColor: c.border,
                      borderBottomWidth: StyleSheet.hairlineWidth,
                    },
                  ]}
                >
                  <Text style={[styles.rowName, { color: c.foreground, flex: 1 }]}>{s}</Text>
                  <Text style={[styles.rowAmount, { color: c.foreground }]}>{n}</Text>
                </View>
              ))}
            </View>
          </Section>
        </>
      )}
    </ScrollView>
  );
}

function StatCard({ label, value, c, icon, highlight }: { label: string; value: string; c: any; icon: any; highlight?: boolean }) {
  return (
    <View
      style={[
        styles.statCard,
        {
          backgroundColor: c.card,
          borderColor: highlight ? c.primary : c.border,
          borderWidth: highlight ? 1 : StyleSheet.hairlineWidth,
        },
      ]}
    >
      <Feather name={icon} size={16} color={highlight ? c.primary : c.mutedForeground} />
      <Text style={[styles.statValue, { color: highlight ? c.primary : c.foreground }]} numberOfLines={1} adjustsFontSizeToFit>
        {value}
      </Text>
      <Text style={[styles.statLabel, { color: c.mutedForeground }]}>{label}</Text>
    </View>
  );
}

function Section({ title, c, children }: { title: string; c: any; children: React.ReactNode }) {
  return (
    <View style={{ marginTop: 24 }}>
      <Text style={[styles.sectionTitle, { color: c.mutedForeground }]}>{title.toUpperCase()}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 28, fontFamily: "Inter_700Bold" },
  subtitle: { fontSize: 13, marginTop: 2, fontFamily: "Inter_400Regular" },
  statGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginTop: 18,
  },
  statCard: {
    flexBasis: "48%",
    flexGrow: 1,
    padding: 14,
    borderRadius: 14,
    gap: 6,
  },
  statValue: { fontSize: 22, fontFamily: "Inter_700Bold", marginTop: 4 },
  statLabel: { fontSize: 12, fontFamily: "Inter_500Medium" },
  sectionTitle: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  listCard: {
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: "hidden",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
  },
  rowName: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  rowSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  rowAmount: { fontSize: 15, fontFamily: "Inter_700Bold" },
  barTrack: {
    height: 4,
    borderRadius: 2,
    marginTop: 6,
    overflow: "hidden",
  },
  barFill: { height: "100%", borderRadius: 2 },
  emptyCard: {
    marginTop: 24,
    padding: 32,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    gap: 12,
  },
  emptyText: { fontSize: 14, textAlign: "center", fontFamily: "Inter_400Regular" },
});

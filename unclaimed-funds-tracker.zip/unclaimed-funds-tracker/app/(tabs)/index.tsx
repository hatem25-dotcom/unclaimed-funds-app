import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AddLeadSheet } from "@/components/AddLeadSheet";
import { FilterSheet } from "@/components/FilterSheet";
import { RecordCard } from "@/components/RecordCard";
import { RecordDetailSheet } from "@/components/RecordDetailSheet";
import { useRecords } from "@/contexts/RecordsContext";
import { useColors } from "@/hooks/useColors";
import {
  DEFAULT_FILTERS,
  Filters,
  Record,
} from "@/types";
import {
  exportRecords,
  pickAndParseFile,
  type ExportFormat,
} from "@/utils/exportImport";

export default function RecordsScreen() {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const { records, loading, addRecord, addRecords, toggleStar } = useRecords();

  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [showFilters, setShowFilters] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [selected, setSelected] = useState<Record | null>(null);
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [showExport, setShowExport] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return records.filter((r) => {
      if (filters.starredOnly && !r.starred) return false;
      if (filters.state && r.state !== filters.state) return false;
      if (filters.minAmount && r.amount < parseFloat(filters.minAmount)) return false;
      if (q) {
        const hay = (r.fullName + " " + r.email).toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    }).sort((a, b) => b.amount - a.amount);
  }, [records, search, filters]);

  const highValue = useMemo(() => records.filter((r) => r.amount > 10000).length, [records]);
  const activeFilterCount =
    (filters.state ? 1 : 0) +
    (filters.starredOnly ? 1 : 0) +
    (filters.minAmount ? 1 : 0);

  const handleImport = async () => {
    try {
      setImporting(true);
      const parsed = await pickAndParseFile();
      if (parsed.length === 0) {
        setImporting(false);
        return;
      }
      const { added, updated } = addRecords(parsed);
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Import complete", `Added ${added} new, updated ${updated}.`);
    } catch (e: any) {
      Alert.alert("Import failed", e?.message ?? "Unknown error");
    } finally {
      setImporting(false);
    }
  };

  const handleExport = async (format: ExportFormat) => {
    setShowExport(false);
    if (records.length === 0) {
      Alert.alert("Nothing to export", "Add some records first.");
      return;
    }
    try {
      setExporting(true);
      const filename = await exportRecords(records, format);
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      if (Platform.OS === "web") {
        Alert.alert("Exported", `Downloaded ${filename}`);
      }
    } catch (e: any) {
      Alert.alert("Export failed", e?.message ?? "Unknown error");
    } finally {
      setExporting(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: c.background, paddingTop: insets.top + 8 }]}>
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: c.foreground }]}>Leads</Text>
          <Text style={[styles.subtitle, { color: c.mutedForeground }]}>
            {records.length} total · {filtered.length} shown
          </Text>
        </View>
        <Pressable
          onPress={() => setShowExport(true)}
          disabled={exporting}
          style={[styles.iconBtn, { backgroundColor: c.card, borderColor: c.border }]}
        >
          {exporting ? (
            <ActivityIndicator color={c.foreground} size="small" />
          ) : (
            <Feather name="download" size={16} color={c.foreground} />
          )}
        </Pressable>
        <Pressable
          onPress={handleImport}
          disabled={importing}
          style={[styles.iconBtn, { backgroundColor: c.card, borderColor: c.border }]}
        >
          {importing ? (
            <ActivityIndicator color={c.foreground} size="small" />
          ) : (
            <Feather name="upload" size={16} color={c.foreground} />
          )}
        </Pressable>
        <Pressable
          onPress={() => setShowAdd(true)}
          style={[styles.importBtn, { backgroundColor: c.primary }]}
        >
          <Feather name="plus" size={14} color={c.primaryForeground} />
          <Text style={[styles.importText, { color: c.primaryForeground }]}>Add Lead</Text>
        </Pressable>
      </View>

      {highValue > 0 ? (
        <View style={[styles.banner, { backgroundColor: c.primary + "15", borderColor: c.primary + "55" }]}>
          <Feather name="zap" size={14} color={c.primary} />
          <Text style={[styles.bannerText, { color: c.primary }]}>
            {highValue} record{highValue === 1 ? "" : "s"} above $10,000
          </Text>
        </View>
      ) : null}

      <View style={styles.searchRow}>
        <View style={[styles.searchBox, { backgroundColor: c.card, borderColor: c.border }]}>
          <Feather name="search" size={16} color={c.mutedForeground} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search name or email..."
            placeholderTextColor={c.mutedForeground}
            autoCapitalize="none"
            autoCorrect={false}
            style={[styles.searchInput, { color: c.foreground }]}
          />
          {search ? (
            <Pressable onPress={() => setSearch("")} hitSlop={8}>
              <Feather name="x" size={16} color={c.mutedForeground} />
            </Pressable>
          ) : null}
        </View>
        <Pressable
          onPress={() => setShowFilters(true)}
          style={[styles.filterBtn, { backgroundColor: c.card, borderColor: activeFilterCount ? c.primary : c.border }]}
        >
          <Feather name="sliders" size={16} color={activeFilterCount ? c.primary : c.foreground} />
          {activeFilterCount > 0 ? (
            <View style={[styles.badge, { backgroundColor: c.primary }]}>
              <Text style={[styles.badgeText, { color: c.primaryForeground }]}>{activeFilterCount}</Text>
            </View>
          ) : null}
        </Pressable>
      </View>

      {loading ? (
        <View style={styles.empty}>
          <ActivityIndicator color={c.primary} />
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.empty}>
          <Feather name="inbox" size={40} color={c.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: c.foreground }]}>
            {records.length === 0 ? "No records yet" : "No matches"}
          </Text>
          <Text style={[styles.emptyText, { color: c.mutedForeground }]}>
            {records.length === 0
              ? "Tap Add Lead, or import a CSV/JSON file."
              : "Try adjusting search or filters."}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 100 }}
          renderItem={({ item }) => (
            <RecordCard
              record={item}
              onPress={() => setSelected(item)}
              onToggleStar={() => toggleStar(item.id)}
            />
          )}
          showsVerticalScrollIndicator={false}
        />
      )}

      <FilterSheet
        visible={showFilters}
        filters={filters}
        onClose={() => setShowFilters(false)}
        onApply={setFilters}
      />
      <AddLeadSheet
        visible={showAdd}
        onClose={() => setShowAdd(false)}
        onSave={(lead) => {
          addRecord(lead);
          if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }}
      />
      <RecordDetailSheet
        record={selected ? records.find((r) => r.id === selected.id) ?? null : null}
        onClose={() => setSelected(null)}
      />

      <Modal
        visible={showExport}
        transparent
        animationType="fade"
        onRequestClose={() => setShowExport(false)}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setShowExport(false)}
        >
          <Pressable
            style={[styles.exportSheet, { backgroundColor: c.card, borderColor: c.border, paddingBottom: insets.bottom + 16 }]}
          >
            <Text style={[styles.exportTitle, { color: c.foreground }]}>Export Data</Text>
            <Text style={[styles.exportSub, { color: c.mutedForeground }]}>
              Save a backup that you can transfer to another device.
            </Text>
            <Pressable
              onPress={() => handleExport("json")}
              style={({ pressed }) => [
                styles.exportOpt,
                { backgroundColor: c.secondary, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Feather name="code" size={18} color={c.foreground} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.exportOptTitle, { color: c.foreground }]}>JSON</Text>
                <Text style={[styles.exportOptSub, { color: c.mutedForeground }]}>
                  Full fidelity backup
                </Text>
              </View>
              <Feather name="chevron-right" size={16} color={c.mutedForeground} />
            </Pressable>
            <Pressable
              onPress={() => handleExport("csv")}
              style={({ pressed }) => [
                styles.exportOpt,
                { backgroundColor: c.secondary, opacity: pressed ? 0.7 : 1, marginTop: 8 },
              ]}
            >
              <Feather name="file-text" size={18} color={c.foreground} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.exportOptTitle, { color: c.foreground }]}>CSV</Text>
                <Text style={[styles.exportOptSub, { color: c.mutedForeground }]}>
                  Open in Excel or Sheets
                </Text>
              </View>
              <Feather name="chevron-right" size={16} color={c.mutedForeground} />
            </Pressable>
            <Pressable
              onPress={() => setShowExport(false)}
              style={[styles.cancel, { borderColor: c.border }]}
            >
              <Text style={{ color: c.mutedForeground, fontFamily: "Inter_500Medium" }}>Cancel</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    marginTop: 4,
    gap: 8,
  },
  title: { fontSize: 28, fontFamily: "Inter_700Bold" },
  subtitle: { fontSize: 13, marginTop: 2, fontFamily: "Inter_400Regular" },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 10,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
  },
  importBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
  },
  importText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  banner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 12,
    marginHorizontal: 16,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: StyleSheet.hairlineWidth,
  },
  bannerText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  searchRow: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    marginTop: 14,
    marginBottom: 6,
  },
  searchBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    height: 44,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
  },
  searchInput: {
    flex: 1,
    fontFamily: "Inter_500Medium",
    fontSize: 14,
    paddingVertical: 0,
  },
  filterBtn: {
    width: 44,
    height: 44,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    position: "absolute",
    top: -4,
    right: -4,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    paddingHorizontal: 4,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: { fontSize: 10, fontFamily: "Inter_700Bold" },
  empty: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    gap: 8,
  },
  emptyTitle: { fontSize: 17, fontFamily: "Inter_600SemiBold", marginTop: 12 },
  emptyText: { fontSize: 14, textAlign: "center", fontFamily: "Inter_400Regular" },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "flex-end",
  },
  exportSheet: {
    padding: 20,
    paddingTop: 24,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: StyleSheet.hairlineWidth,
    borderRightWidth: StyleSheet.hairlineWidth,
  },
  exportTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  exportSub: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 4, marginBottom: 16 },
  exportOpt: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 12,
  },
  exportOptTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  exportOptSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  cancel: {
    marginTop: 12,
    padding: 14,
    borderRadius: 12,
    alignItems: "center",
    borderWidth: StyleSheet.hairlineWidth,
  },
});

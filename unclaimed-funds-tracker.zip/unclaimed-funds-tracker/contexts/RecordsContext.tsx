import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { Record, Status } from "@/types";

const STORAGE_KEY = "@unclaimed_records_v1";
const TEMPLATE_KEY = "@unclaimed_template_v1";

const DEFAULT_TEMPLATE = "Hello {name}, you may have {amount} in {state}";

interface Ctx {
  records: Record[];
  loading: boolean;
  template: string;
  setTemplate: (t: string) => void;
  addRecord: (r: Omit<Record, "id" | "createdAt">) => void;
  addRecords: (r: Record[]) => { added: number; updated: number };
  updateRecord: (id: string, patch: Partial<Record>) => void;
  toggleStar: (id: string) => void;
  setStatus: (id: string, status: Status) => void;
  deleteRecord: (id: string) => void;
  clearAll: () => void;
}

const RecordsContext = createContext<Ctx | null>(null);

export function RecordsProvider({ children }: { children: React.ReactNode }) {
  const [records, setRecords] = useState<Record[]>([]);
  const [template, setTemplateState] = useState<string>(DEFAULT_TEMPLATE);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) setRecords(JSON.parse(raw));
        const tpl = await AsyncStorage.getItem(TEMPLATE_KEY);
        if (tpl) setTemplateState(tpl);
      } catch {}
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (loading) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(records)).catch(() => {});
  }, [records, loading]);

  const setTemplate = useCallback((t: string) => {
    setTemplateState(t);
    AsyncStorage.setItem(TEMPLATE_KEY, t).catch(() => {});
  }, []);

  const addRecord = useCallback((r: Omit<Record, "id" | "createdAt">) => {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    setRecords((prev) => [{ ...r, id, createdAt: Date.now() }, ...prev]);
  }, []);

  const addRecords = useCallback((incoming: Record[]) => {
    let added = 0;
    let updated = 0;
    setRecords((prev) => {
      const map = new Map<string, Record>();
      for (const r of prev) {
        const key = (r.email || r.fullName).toLowerCase();
        map.set(key, r);
      }
      for (const r of incoming) {
        const key = (r.email || r.fullName).toLowerCase();
        const ex = map.get(key);
        if (ex) {
          map.set(key, {
            ...ex,
            fullName: r.fullName || ex.fullName,
            amount: r.amount || ex.amount,
            state: r.state || ex.state,
            email: r.email || ex.email,
            status: r.status,
            starred: ex.starred || r.starred,
          });
          updated++;
        } else {
          map.set(key, r);
          added++;
        }
      }
      return Array.from(map.values());
    });
    return { added, updated };
  }, []);

  const updateRecord = useCallback((id: string, patch: Partial<Record>) => {
    setRecords((prev) =>
      prev.map((r) => (r.id === id ? { ...r, ...patch } : r))
    );
  }, []);

  const toggleStar = useCallback((id: string) => {
    setRecords((prev) =>
      prev.map((r) => (r.id === id ? { ...r, starred: !r.starred } : r))
    );
  }, []);

  const setStatus = useCallback((id: string, status: Status) => {
    setRecords((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status } : r))
    );
  }, []);

  const deleteRecord = useCallback((id: string) => {
    setRecords((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setRecords([]);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      records,
      loading,
      template,
      setTemplate,
      addRecord,
      addRecords,
      updateRecord,
      toggleStar,
      setStatus,
      deleteRecord,
      clearAll,
    }),
    [records, loading, template, setTemplate, addRecord, addRecords, updateRecord, toggleStar, setStatus, deleteRecord, clearAll]
  );

  return (
    <RecordsContext.Provider value={value}>{children}</RecordsContext.Provider>
  );
}

export function useRecords() {
  const ctx = useContext(RecordsContext);
  if (!ctx) throw new Error("useRecords must be used within RecordsProvider");
  return ctx;
}

export function formatMoney(n: number): string {
  return "$" + n.toLocaleString("en-US", { maximumFractionDigits: 2 });
}

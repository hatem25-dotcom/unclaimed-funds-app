# Unclaimed Funds Tracker

A simple, fast, dark-mode mobile app for tracking people with unclaimed funds.
Built with Expo (SDK 54), React Native, and AsyncStorage.

## Features

- Local persistent storage (AsyncStorage)
- Manual lead entry + CSV/JSON import
- CSV/JSON export (share / save to device)
- Search by name or email
- Filter by state, minimum amount, starred
- Star toggle for important leads
- Status: Pending / Contacted / Replied
- High-value alert (records > $10,000)
- Editable message template with copy-to-clipboard
- One-tap email button (opens default mail app)
- Dark mode only, no animations, lightweight

---

## Build an installable APK with EAS (free)

The project is fully configured. You need a free Expo account
([sign up here](https://expo.dev/signup)).

### From any computer with Node.js installed:

```bash
npm install -g eas-cli
npm install
eas login
eas build -p android --profile preview
```

When the build finishes (10–20 min), the terminal will print a download
link to the `.apk`. Open the link on your Android phone, tap install, done.

You can also see/download all your builds at <https://expo.dev>.

### Build profiles (in `eas.json`)

| Profile        | Output | Use for                              |
| -------------- | ------ | ------------------------------------ |
| `preview`      | APK    | Sideload on your own Android phone   |
| `development`  | APK    | Dev client with hot reload           |
| `production`   | AAB    | Google Play Store submission         |

---

## Run locally for development

```bash
npm install
npm start            # Expo dev server (scan QR code with Expo Go)
npm run android      # build & run on connected Android device/emulator
npm run web          # run in browser
```

---

## App configuration

App metadata is in `app.json`:

- **Name**: Unclaimed Funds Tracker
- **Android package**: `com.unclaimedfunds.tracker`
- **iOS bundle id**: `com.unclaimedfunds.tracker`
- **Version**: 1.0.0 (versionCode 1)

To rename the app or change branding, edit `app.json` and replace
`assets/images/icon.png` (1024×1024 PNG).
